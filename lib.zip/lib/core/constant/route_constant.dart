class RouteConstant{
  static const String nome = '/home_page.dart';
  static const String login = '/login_page.dart';
  static const String dashboard = '/dashboard_page.dart';
  static const String signup = '/signup_page.dart';
  static const String signupTwo = '/bottambar_signup2.dart';
  static const String bottam2 ='/profile_pageview.dart';
}
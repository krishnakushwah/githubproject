import 'dart:convert';
import 'package:get/get.dart';
import 'package:krishnakushwahtest2/core/model/signup_data_fetchresponse.dart';
import 'package:krishnakushwahtest2/core/model/signup_response.dart';
import 'package:krishnakushwahtest2/core/repository/Bottambar/bottambar_repo.dart';
import 'package:krishnakushwahtest2/httpServices/http_service_impl.dart';
import 'package:krishnakushwahtest2/httpServices/http_services.dart';

class Bottambarimple implements BottambarRepo{
  late HttpService _httpService;
  Bottambarimple() {
    _httpService = Get.put(HttpServiceImpl());
    _httpService.init();
  }


  @override
  Future<List<Bottamfetch>?> FetchDataAPI(String phone)async {
    // TODO: implement FetchDataAPI
    try {
      final response = await _httpService.FetchDataAPIRequest(phone);
      if (response.statusCode == 200) {
        return BottamfetchFromJson(response.toString());
      }
    } on Exception catch (e) {
      print(e);
      return null;
    }
    return null;
  }
  List<Bottamfetch> BottamfetchFromJson(String str) => List<Bottamfetch>.from(json.decode(str).map((x) => Bottamfetch.fromJson(x)));

  // @override
  // Future<SIgnupResponse> DeleteAPI(String id) async{
  //   // TODO: implement DeleteAPI
  //   final response = await _httpService.DeleteAPIRequest(id);
  //   Map<String, dynamic> ResponseMap = Map.from(jsonDecode(response.data));
  //   return SIgnupResponse.fromJson(ResponseMap);
  // }
  //
  // @override
  // Future<SIgnupResponse> UpdatedataAPI(String id) async{
  //   // TODO: implement UpdatedataAPI
  //   final response = await _httpService.UpdatedataAPIRequest(id);
  //   Map<String, dynamic> ResponseMap = Map.from(jsonDecode(response.data));
  //   return SIgnupResponse.fromJson(ResponseMap);
  // }

}
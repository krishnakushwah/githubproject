import 'package:krishnakushwahtest2/core/model/signup_data_fetchresponse.dart';
import 'package:krishnakushwahtest2/core/model/signup_response.dart';

abstract class BottambarRepo{
  Future<List<Bottamfetch>?>FetchDataAPI(String phone);
  // Future<SIgnupResponse> UpdatedataAPI(String id);
  // Future<SIgnupResponse>DeleteAPI(String id);

}
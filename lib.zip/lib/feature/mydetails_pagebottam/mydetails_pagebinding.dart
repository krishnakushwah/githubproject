import 'package:get/get.dart';
import 'package:krishnakushwahtest2/feature/mydetails_pagebottam/mydetails_pagecontroller.dart';

class BottamMydetailsBinding extends Bindings{
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.put(BottamMydetailsController());
  }

}
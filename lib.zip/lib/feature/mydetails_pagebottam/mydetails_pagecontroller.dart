import 'package:get/get.dart';
import 'package:krishnakushwahtest2/core/repository/Bottambar/bottambar_repo.dart';
import 'package:krishnakushwahtest2/core/repository/Bottambar/bottambar_repo_imple.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BottamMydetailsController extends GetxController{


  late BottambarRepo _BottambarRepo;


  BottamprofileController(){
    _BottambarRepo = Get.find<Bottambarimple>();
  }
  // UpdateData(String id) async{
  //   final FinalResponse = await _BottambarRepo.UpdatedataAPI(id);
  // }
  // DeleteData(String id)async{
  //   final response = await _BottambarRepo.DeleteAPI(id);
  //   print("Line Number 35");
  //   print(response);
  //  // print(response.response);
  //  //  if(response!=null) {
  //  //    SharedPreferences prefs = await SharedPreferences.getInstance();
  //  //    prefs.setString("loginName", response.name!);
  //  //
  //  //  }



}

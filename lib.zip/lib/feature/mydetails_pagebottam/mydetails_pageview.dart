import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:krishnakushwahtest2/feature/mydetails_pagebottam/mydetails_pagecontroller.dart';

class Bottammydetailview extends GetView<BottamMydetailsController>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("Bottam Mydetail view"),

      ),
      body: Container(

       width:500,
        height:220,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,

          child: DataTable(
     border: TableBorder.all(),
            // Datatable widget that have the property columns and rows.
              columns: [
                // Set the name of the column
                DataColumn(label: Text('Name',style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 17),)),
                DataColumn(label: Text('Email', style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 17),)),
                DataColumn(label: Text('Password',style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 17),)),
                DataColumn(label: Text('Edit',style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 17),)),
                DataColumn(label: Text('Delete',style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 17),)),
              ],
              rows:[
                // Set the values to the columns
                DataRow(cells: [
                  DataCell(Text("krishna kushwah")),
                  DataCell(Text("krishna@gmail.com")),
                  DataCell(Text("1234")),
                  DataCell(IconButton(onPressed:(){}, color: Colors.green,icon: const Icon(Icons.edit))),
                  DataCell(IconButton(onPressed:(){}, color: Colors.red,icon: const Icon(Icons.delete))),
                ]),
                DataRow(cells:[
                  DataCell(Text("krishna kushwah")),
                  DataCell(Text("krishna@gmail.com")),
                  DataCell(Text("1234")),
                  DataCell(IconButton(onPressed:(){},icon: const Icon(Icons.edit))),
                  DataCell(IconButton(onPressed:(){},icon: const Icon(Icons.delete))),

                ]),
              ]
          ),
        ),
      ),

    );
  }

}
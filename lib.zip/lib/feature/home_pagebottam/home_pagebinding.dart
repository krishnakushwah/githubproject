import 'package:get/get.dart';
import 'package:krishnakushwahtest2/feature/home_pagebottam/home_pagecontroller.dart';

class Bottamhomebinding extends Bindings{
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.put(BottamhomeController());
  }

}
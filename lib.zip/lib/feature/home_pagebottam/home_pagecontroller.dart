import 'package:get/get.dart';

class BottamhomeController extends GetxController{


}
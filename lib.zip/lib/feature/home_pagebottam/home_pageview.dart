import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:krishnakushwahtest2/feature/home_pagebottam/home_pagecontroller.dart';

class Bottamhomeview extends GetView<BottamhomeController>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("krishna Home view"),
      ),
    );
  }

}
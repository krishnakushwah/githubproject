import 'package:get/get.dart';
import 'package:krishnakushwahtest2/core/constant/route_constant.dart';
import 'package:krishnakushwahtest2/feature/Profile_pagebottam/profile_pageview.dart';
import 'package:krishnakushwahtest2/feature/home_pagebottam/home_pageview.dart';
import 'package:krishnakushwahtest2/feature/mydetails_pagebottam/mydetails_pageview.dart';


class SignupControllerTwo extends GetxController{
 var currentIndex=0.obs;

 void changeIndex( var _index){
    print(_index);
    currentIndex.value= _index;

}

}
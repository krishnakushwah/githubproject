import 'package:get/get.dart';
import 'package:krishnakushwahtest2/core/repository/Bottambar/bottambar_repo_imple.dart';
import 'package:krishnakushwahtest2/feature/Profile_pagebottam/profile_pagecontroller.dart';
import 'package:krishnakushwahtest2/feature/bottambar_firstview/controller/controller_signup2.dart';
import 'package:krishnakushwahtest2/feature/mydetails_pagebottam/mydetails_pagecontroller.dart';

class SignupTwoBinding extends Bindings{
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.lazyPut(() => BottamprofileController());
    Get.lazyPut(() => BottamMydetailsController());

    Get.lazyPut(() => SignupControllerTwo());
    Get.put(SignupControllerTwo());
    Get.put(Bottambarimple());
  }
}
import 'package:get/get.dart';
import 'package:krishnakushwahtest2/core/model/signup_data_fetchresponse.dart';
import 'package:krishnakushwahtest2/core/repository/Bottambar/bottambar_repo.dart';
import 'package:krishnakushwahtest2/core/repository/Bottambar/bottambar_repo_imple.dart';

class BottamprofileController extends GetxController{
  List<Bottamfetch>internDataList = <Bottamfetch>[];
late BottambarRepo _BottambarRepo;


  BottamprofileController(){
    _BottambarRepo = Get.find<Bottambarimple>();
  }
 var phone ='9907752533';
  RxString name = " ".obs;
  RxString emailId = " ".obs;
  RxString phoneno = " ".obs;
  RxString password= " ".obs;


  RxBool loader = false.obs;
  fetchDataInterns() async {
    loader.value = false;
    final fetchResponse = await _BottambarRepo.FetchDataAPI(phone);
    if (fetchResponse != null) {
      loader.value = true;
      internDataList = fetchResponse;
      print("data is fetch now....");
      print(fetchResponse[0].id);
      print(fetchResponse[0].name);
      print(fetchResponse[0].emailId);
      print(fetchResponse[0].phone);
      print(fetchResponse[0].password);

      loader.value = false;
      print(loader.value);

      name.value = fetchResponse[0].name!;
      emailId.value = fetchResponse[0].emailId!;
      phoneno.value = fetchResponse[0].phone!;
      password.value = fetchResponse[0].password!;


    }
    print("Line Number 33");
  }
  @override
  void onInit()async{
    fetchDataInterns();
    super.onInit();

  }




}




import 'package:dio/dio.dart';
import 'package:dio/src/response.dart';
import 'package:krishnakushwahtest2/core/url_constant.dart';
import 'package:krishnakushwahtest2/httpServices/http_services.dart';



class HttpServiceImpl implements HttpService{
  late Dio _dio;

  @override
  void init() {
    _dio = Dio(BaseOptions(baseUrl: URLConstant.baseUrl));
  }
  @override
  Future<Response> signupAPIRequest(String Name,String Email,String Password,String Phone) async{
    // TODO: implement loginAPIRequest
    Response response;
    try{
      print(URLConstant.baseUrl+URLConstant.signup+'name=$Name&emailId=$Email&password=$Password&phone=$Phone');
      response = await _dio.post(URLConstant.baseUrl+URLConstant.signup+'name=$Name&emailId=$Email&password=$Password&phone=$Phone');
    } on DioError catch (e) {
      print(e.message);
      throw Exception(e.message);
    }
    return response;
  }


  @override
  Future<Response> FetchDataAPIRequest(String phone) async {
    Response response;
    try
    {
      response = await _dio.get('${URLConstant.datafetch}phone=$phone');
    } on DioError catch (e)
    {
      throw Exception(e.message);
    }
    return response;
  }
  //
  // @override
  // Future<Response> DeleteAPIRequest(id) async{
  //   // TODO: implement id
  //   Response response;
  //   try {
  //     print(URLConstant.baseUrl+URLConstant.deleteDataIntern+'id=$id');
  //     response = await _dio.post(URLConstant.baseUrl+URLConstant.deleteDataIntern+'id=$id');
  //   } on DioError catch (e) {
  //     print(e.message);
  //     throw Exception(e.message);
  //   }
  //   return response;
  // }
  //
  // @override
  // Future<Response> UpdatedataAPIRequest(id) async {
  //   // TODO: implement updatedataAPIRequest
  //   Response response;
  //   try
  //   {print('${URLConstant.updateData}id=$id');
  //     response = await _dio.get('${URLConstant.updateData}id=$id');
  //   } on DioError catch (e)
  //   {
  //     throw Exception(e.message);
  //   }
  //   return response;
  // }
  //


}


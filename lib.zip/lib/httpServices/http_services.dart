import 'package:dio/dio.dart';

abstract class HttpService {
  void init();

  Future<Response> signupAPIRequest(String Name,String Email,String Password,String Phone);

    Future<Response> FetchDataAPIRequest( String Phone);
  // Future<Response> UpdatedataAPIRequest(id);
  // Future<Response> DeleteAPIRequest(id);
}